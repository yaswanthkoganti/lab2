package com.website.airline;

public class FareBean {

	
	private int flightNumber;
	private String fareCode;
	private int amount;
	private String restrictions;
	
	
	public int getFlightNumber() {
		return flightNumber;
	}
	public void setFlightNumber(int flightNumber) {
		this.flightNumber = flightNumber;
	}
	public String getFareCode() {
		return fareCode;
	}
	public void setFareCode(String fareCode) {
		this.fareCode = fareCode;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public String getRestrictions() {
		return restrictions;
	}
	public void setRestrictions(String restrictions) {
		this.restrictions = restrictions;
	}
	
	
	
	
}
