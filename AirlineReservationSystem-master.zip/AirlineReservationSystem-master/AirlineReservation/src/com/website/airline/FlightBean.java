package com.website.airline;

public class FlightBean {
	
	
	private String firstFlightNumber;
	private String secondFlightNumber;
	private String thirdFlightNumber;

	private String origin;
	private String destination;
	private String firstStop;
	private String secondStop;
	
	private String firstWeekday;
	private String secondWeekday;
	private String thirdWeekday;
	
	
	
	private String firstDepart;
	private String firstArrive;
	private String secondDepart;
	private String secondArrive;
	private String thirdDepart;
	private String thridArrive;
	
	
	
	
	
	public String getFirstDepart() {
		return firstDepart;
	}
	public void setFirstDepart(String firstDepart) {
		this.firstDepart = firstDepart;
	}
	public String getFirstArrive() {
		return firstArrive;
	}
	public void setFirstArrive(String firstArrive) {
		this.firstArrive = firstArrive;
	}
	public String getSecondDepart() {
		return secondDepart;
	}
	public void setSecondDepart(String secondDepart) {
		this.secondDepart = secondDepart;
	}
	public String getSecondArrive() {
		return secondArrive;
	}
	public void setSecondArrive(String secondArrive) {
		this.secondArrive = secondArrive;
	}
	public String getThirdDepart() {
		return thirdDepart;
	}
	public void setThirdDepart(String thirdDepart) {
		this.thirdDepart = thirdDepart;
	}
	public String getThridArrive() {
		return thridArrive;
	}
	public void setThridArrive(String thridArrive) {
		this.thridArrive = thridArrive;
	}
	public String getFirstWeekday() {
		return firstWeekday;
	}
	public void setFirstWeekday(String firstWeekday) {
		this.firstWeekday = firstWeekday;
	}
	public String getSecondWeekday() {
		return secondWeekday;
	}
	public void setSecondWeekday(String secondWeekday) {
		this.secondWeekday = secondWeekday;
	}
	public String getThirdWeekday() {
		return thirdWeekday;
	}
	public void setThirdWeekday(String thirdWeekday) {
		this.thirdWeekday = thirdWeekday;
	}
	public String getFirstFlightNumber() {
		return firstFlightNumber;
	}
	public void setFirstFlightNumber(String firstFlightNumber) {
		this.firstFlightNumber = firstFlightNumber;
	}
	public String getSecondFlightNumber() {
		return secondFlightNumber;
	}
	public void setSecondFlightNumber(String secondFlightNumber) {
		this.secondFlightNumber = secondFlightNumber;
	}
	public String getThirdFlightNumber() {
		return thirdFlightNumber;
	}
	public void setThirdFlightNumber(String thirdFlightNumber) {
		this.thirdFlightNumber = thirdFlightNumber;
	}
	public String getOrigin() {
		return origin;
	}
	public void setOrigin(String origin) {
		this.origin = origin;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public String getFirstStop() {
		return firstStop;
	}
	public void setFirstStop(String firstStop) {
		this.firstStop = firstStop;
	}
	public String getSecondStop() {
		return secondStop;
	}
	public void setSecondStop(String secondStop) {
		this.secondStop = secondStop;
	}
	
	
	
}
