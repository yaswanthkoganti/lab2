package com.author.recharge.exception;

public class InvalidPlanName extends Exception{
private String msg;
public InvalidPlanName()
{
	
}
public InvalidPlanName(String msg)
{
this.msg=msg;
}
public String toString()
{
	return this.msg;
}
}
