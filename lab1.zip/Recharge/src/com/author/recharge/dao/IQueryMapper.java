package com.author.recharge.dao;

public interface IQueryMapper {

}
