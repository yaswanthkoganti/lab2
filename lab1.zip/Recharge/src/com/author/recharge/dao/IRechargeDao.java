package com.author.recharge.dao;

import java.sql.SQLException;

import com.author.recharge.bean.RechargeBean;

public interface IRechargeDao {
	StringBuilder displayPlans() throws SQLException;
	void addUserDetails(String name,String mobile,String status,String planName,int amount) throws SQLException;
	boolean retrieveUserDetails(String rechId,RechargeBean b1) throws SQLException;
	int retrieveAmount(String plan) throws SQLException;
}
