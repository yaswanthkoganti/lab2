package com.author.recharge.dao;

import java.beans.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.author.recharge.bean.RechargeBean;
import com.author.recharge.exception.InvalidPlanName;
import com.author.recharge.exception.InvalidRechId;
import com.author.recharge.service.IRechargeService;
import com.author.recharge.service.RechargeServiceImpl;


public class RechargeDaoImpl implements IRechargeDao{
private static boolean created=true;
	@Override
	public StringBuilder displayPlans() throws SQLException {
		Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg1110","training1110");
		java.sql.Statement s=conn.createStatement();
		String s1="select * from plans";
		ResultSet r=s.executeQuery(s1);
		StringBuilder s2=new StringBuilder("");
		s2.append("plans      amount\n");
		while(r.next())
		{
			s2.append(r.getString(1)+"     "+r.getInt(2)+"\n");
		}		
		return s2;
	}

	@Override
	public void addUserDetails(String name,String mobile,String status,String planName,int amount) throws SQLException {
		Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg1110","training1110");
		if(created==false)
		{
			creation();
		}
		String s1="Select rech_Id.nextval from dual";
		java.sql.Statement ss=conn.createStatement();
		ResultSet rs=ss.executeQuery(s1);
		rs.next();
		String str=rs.getString(1);
		//try{
			String st="select count(*) from plans where planname='"+planName+"'";
			java.sql.Statement sn=conn.createStatement();
			ResultSet rs1=sn.executeQuery(st);
			rs1.next();
			int count=Integer.parseInt(rs1.getString(1));
		if(count<=0)
		{
			status="Failed";
		}
		else
			status="Success";
		String s2="insert into rechargeInfo values(?,?,?,?,?,?)";
		PreparedStatement s=conn.prepareStatement(s2);
		//s.executeUpdate();
		//s=conn.prepareStatement(s2);
		//PreparedStatement ss=conn.prepareStatement(s2);
		//ss.executeUpdate();
		//ss=conn.prepareStatement(s2);
		//s.execute("SELECT CUST_SEQUENCE.NEXTVAL FROM DUAL");
		s.setString(1,str);
		s.setString(2,name);
		s.setString(3,mobile);
		s.setString(4,status);
		s.setString(5,planName);
		s.setInt(6,amount);
		s.executeUpdate();
		IRechargeService serv=new RechargeServiceImpl();
		serv.rechargeStatus(str);
		}
	/*
		catch(InvalidPlanName e)
		{
		
			System.out.println(e);
			return true;
		}
			}*/
	@Override
	public boolean retrieveUserDetails(String rechId,RechargeBean bean) throws SQLException {
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg1110","training1110");
		try{
		String st="select count(*) from rechargeinfo where rechId='"+rechId+"'";
		java.sql.Statement sn=con.createStatement();
		ResultSet rs1=sn.executeQuery(st);
		rs1.next();
		int count=Integer.parseInt(rs1.getString(1));
		if(count<=0)
		{
			throw new InvalidRechId();
		}
		else
		{
			PreparedStatement ps=con.prepareStatement("Select * from rechargeinfo where rechId='"+rechId+"'");
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
		
				bean.setRechId(rechId);
				bean.setUserName(rs.getString(2));
				bean.setUserMobileNum(rs.getString(3));
				bean.setStatus(rs.getString(4));
				bean.setPlanName(rs.getString(5));
				bean.setAmount(rs.getInt(6));
			}
			return false;
		}
		}
		catch(InvalidRechId r)
		{
			System.out.println(r);
			return true;
		}
	
			
	}

	@Override
	public int retrieveAmount(String plan) throws SQLException {
		Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg1110","training1110");
		String s1="select amount from plans where planname='"+plan+"'";
		java.sql.Statement s=conn.createStatement();
		//String s1="select * from plans";
		int amount=0;
		ResultSet r=s.executeQuery(s1);
		while(r.next())
		{
			amount=r.getInt(1);
		}
		//ResultSet r=s.executeQuery(s1);
		return amount;
	}
	public void creation() throws SQLException
	{
		Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg1110","training1110");
		String s1="create sequence rech_Id start with 100000  increment by 1 NOCYCLE";
		PreparedStatement s=conn.prepareStatement(s1);
		s.executeUpdate();
		created=true;
	}
	
}
