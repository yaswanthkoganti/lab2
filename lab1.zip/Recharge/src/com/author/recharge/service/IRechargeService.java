package com.author.recharge.service;

import java.sql.SQLException;

import com.author.recharge.bean.RechargeBean;

public interface IRechargeService {
	StringBuilder displayPlans() throws SQLException;
	void addUserDetails(RechargeBean r) throws SQLException;
	boolean retrieveUserDetails(String rechId,RechargeBean b1) throws SQLException;
	int retrieveAmount(String plan) throws SQLException;
	public void rechargeStatus(String rechId);
	public boolean isValidMobile(String str);
	public boolean isValidName(String str);
	
	
}
