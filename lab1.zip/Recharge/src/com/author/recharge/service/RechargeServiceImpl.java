package com.author.recharge.service;

import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.author.recharge.bean.RechargeBean;
import com.author.recharge.dao.IRechargeDao;
import com.author.recharge.dao.RechargeDaoImpl;

public class RechargeServiceImpl implements IRechargeService{
private static String status;
@Override
	public StringBuilder displayPlans() throws SQLException {
		IRechargeDao i=new RechargeDaoImpl();
		return i.displayPlans();
	}

	@Override
	public void addUserDetails(RechargeBean rb) throws SQLException {
		// TODO Auto-generated method stub
		IRechargeDao r=new RechargeDaoImpl();
		r.addUserDetails(rb.getUserName(),rb.getUserMobileNum(),rb.getStatus(),rb.getPlanName(),rb.getAmount());
	
	}

	@Override
	public boolean retrieveUserDetails(String rechId,RechargeBean  b1) throws SQLException {
		IRechargeDao r=new RechargeDaoImpl();
		return r.retrieveUserDetails(rechId,b1);
		
	}
	public void rechargeStatus(String rechId)
	{
		if(!status.equals("success"))
		System.out.println("Your mobile has been recharged...rech id is <"+rechId+">");
		else
			System.out.println("Your recharge Id is<"+rechId+">.Please Check your status...");
	}

	@Override
	public int retrieveAmount(String plan) throws SQLException {
		IRechargeDao i=new RechargeDaoImpl();
		return i.retrieveAmount(plan);
	}
	public boolean isValidMobile(String mobileNum)
	{
		Pattern p=Pattern.compile("[0-9]{10}");
		Matcher m=p.matcher(mobileNum);
		return m.matches();
	}

}
